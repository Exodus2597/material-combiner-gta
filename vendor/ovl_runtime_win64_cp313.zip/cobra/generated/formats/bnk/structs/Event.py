from generated.array import Array
from generated.formats.bnk.imports import name_type_map
from generated.formats.bnk.structs.HircObject import HircObject


class Event(HircObject):

	__name__ = 'Event'


	def __init__(self, context, arg=0, template=None, set_default=True):
		super().__init__(context, arg, template, set_default=False)

		# todo varint
		self.num_actions = name_type_map['Ubyte'](self.context, 0, None)
		self.children = Array(self.context, 0, None, (0,), name_type_map['Uint'])
		if set_default:
			self.set_defaults()

	@classmethod
	def _get_attribute_list(cls):
		yield from super()._get_attribute_list()
		yield 'num_actions', name_type_map['Uint'], (0, None), (False, None), (lambda context: context.version <= 122, None)
		yield 'num_actions', name_type_map['Ubyte'], (0, None), (False, None), (lambda context: context.version >= 123, None)
		yield 'children', Array, (0, None, (None,), name_type_map['Uint']), (False, None), (None, None)

	@classmethod
	def _get_filtered_attribute_list(cls, instance, include_abstract=True):
		yield from super()._get_filtered_attribute_list(instance, include_abstract)
		if instance.context.version <= 122:
			yield 'num_actions', name_type_map['Uint'], (0, None), (False, None)
		if instance.context.version >= 123:
			yield 'num_actions', name_type_map['Ubyte'], (0, None), (False, None)
		yield 'children', Array, (0, None, (instance.num_actions,), name_type_map['Uint']), (False, None)
