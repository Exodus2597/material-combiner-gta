from generated.array import Array
from generated.formats.bnk.imports import name_type_map
from generated.formats.bnk.structs.HircObject import HircObject


class MusicTrack(HircObject):

	__name__ = 'MusicTrack'


	def __init__(self, context, arg=0, template=None, set_default=True):
		super().__init__(context, arg, template, set_default=False)
		self.u_flags = name_type_map['Ubyte'](self.context, 0, None)
		self.num_sources = name_type_map['Uint'](self.context, 0, None)
		self.ak_bank_source_data = Array(self.context, 0, None, (0,), name_type_map['AkBankSourceData'])
		self.num_playlist_item = name_type_map['Uint'](self.context, 0, None)
		self.p_playlist = Array(self.context, 0, None, (0,), name_type_map['AkTrackSrcInfo'])
		self.num_sub_track = name_type_map['Uint'](self.context, 0, None)
		self.num_clip_automation_item = name_type_map['Uint'](self.context, 0, None)
		self.p_items = Array(self.context, 0, None, (0,), name_type_map['AkClipAutomation'])
		self.node_base_params = name_type_map['NodeBaseParams'](self.context, 0, None)
		self.e_track_type = name_type_map['Ubyte'](self.context, 0, None)
		self.switch_params = name_type_map['SwitchParams'](self.context, 0, None)
		self.trans_params = name_type_map['TransParams'](self.context, 0, None)
		self.i_look_ahead_time = name_type_map['Int'](self.context, 0, None)
		if set_default:
			self.set_defaults()

	@classmethod
	def _get_attribute_list(cls):
		yield from super()._get_attribute_list()
		yield 'u_flags', name_type_map['Ubyte'], (0, None), (False, None), (None, None)
		yield 'num_sources', name_type_map['Uint'], (0, None), (False, None), (None, None)
		yield 'ak_bank_source_data', Array, (0, None, (None,), name_type_map['AkBankSourceData']), (False, None), (None, None)
		yield 'num_playlist_item', name_type_map['Uint'], (0, None), (False, None), (None, None)
		yield 'p_playlist', Array, (0, None, (None,), name_type_map['AkTrackSrcInfo']), (False, None), (None, None)
		yield 'num_sub_track', name_type_map['Uint'], (0, None), (False, None), (None, None)
		yield 'num_clip_automation_item', name_type_map['Uint'], (0, None), (False, None), (None, None)
		yield 'p_items', Array, (0, None, (None,), name_type_map['AkClipAutomation']), (False, None), (None, None)
		yield 'node_base_params', name_type_map['NodeBaseParams'], (0, None), (False, None), (None, None)
		yield 'e_track_type', name_type_map['Ubyte'], (0, None), (False, None), (None, None)
		yield 'switch_params', name_type_map['SwitchParams'], (0, None), (False, None), (None, True)
		yield 'trans_params', name_type_map['TransParams'], (0, None), (False, None), (None, True)
		yield 'i_look_ahead_time', name_type_map['Int'], (0, None), (False, None), (None, None)

	@classmethod
	def _get_filtered_attribute_list(cls, instance, include_abstract=True):
		yield from super()._get_filtered_attribute_list(instance, include_abstract)
		yield 'u_flags', name_type_map['Ubyte'], (0, None), (False, None)
		yield 'num_sources', name_type_map['Uint'], (0, None), (False, None)
		yield 'ak_bank_source_data', Array, (0, None, (instance.num_sources,), name_type_map['AkBankSourceData']), (False, None)
		yield 'num_playlist_item', name_type_map['Uint'], (0, None), (False, None)
		yield 'p_playlist', Array, (0, None, (instance.num_playlist_item,), name_type_map['AkTrackSrcInfo']), (False, None)
		yield 'num_sub_track', name_type_map['Uint'], (0, None), (False, None)
		yield 'num_clip_automation_item', name_type_map['Uint'], (0, None), (False, None)
		yield 'p_items', Array, (0, None, (instance.num_clip_automation_item,), name_type_map['AkClipAutomation']), (False, None)
		yield 'node_base_params', name_type_map['NodeBaseParams'], (0, None), (False, None)
		yield 'e_track_type', name_type_map['Ubyte'], (0, None), (False, None)
		if instance.e_track_type == 3:
			yield 'switch_params', name_type_map['SwitchParams'], (0, None), (False, None)
			yield 'trans_params', name_type_map['TransParams'], (0, None), (False, None)
		yield 'i_look_ahead_time', name_type_map['Int'], (0, None), (False, None)
